/**
 * Employer Jobs API
 *
 * Handles employer portal operations: authenticating employers,
 * listing their jobs, submitting new listings, editing, relisting,
 * closing, upgrading plans, and deleting employer accounts.
 *
 * GET  ?email=&password=        - Fetch employer profile and jobs
 * POST { action, email, password, ... }
 *
 * Actions:
 *   list           - List employer jobs (same as GET, via POST)
 *   upgrade        - Change employer plan
 *   submit         - Submit a new job listing
 *   edit           - Edit an existing listing
 *   relist         - Relist an expired/closed listing
 *   close          - Close an active listing
 *   delete-account - Delete employer account and all their jobs
 */

var config = require("../config");
var _kv = require("./_kv");
var getKV = _kv.getKV;
var hget = _kv.hget;
var hgetall = _kv.hgetall;
var hset = _kv.hset;
var verifyPassword = _kv.verifyPassword;
var isHashed = _kv.isHashed;
var hashPassword = _kv.hashPassword;

var ADMIN_EMAIL = process.env.ADMIN_EMAIL || ("hello@" + config.emailFromDomain);

/**
 * Build plan limits and duration lookups from config.plans.
 */
var PLAN_LIMITS = {};
var PLAN_DAYS = {};
var PLAN_NAMES = {};
Object.keys(config.plans).forEach(function(key) {
  var plan = config.plans[key];
  PLAN_LIMITS[key] = plan.maxListings === -1 ? 999 : (plan.maxListings || 1);
  PLAN_DAYS[key] = plan.durationDays || 30;
  PLAN_NAMES[key] = plan.name || key;
});

/**
 * Send a notification email to the admin when a new job is submitted.
 *
 * @param {string} subject  - Email subject
 * @param {string} bodyHtml - Inner HTML body
 */
function notifyAdmin(subject, bodyHtml) {
  var resendKey = process.env.RESEND_API_KEY;
  if (!resendKey) return;
  var fromAddress = config.emailFromName + " <hello@" + config.emailFromDomain + ">";
  fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": "Bearer " + resendKey },
    body: JSON.stringify({
      from: fromAddress,
      to: [ADMIN_EMAIL],
      subject: subject,
      html: '<div style="font-family:sans-serif;font-size:15px;line-height:1.7;color:#333">' + bodyHtml + '</div>'
    })
  }).catch(function() {});
}

module.exports = async function handler(req, res) {
  if (!getKV()) return res.status(500).json({ error: "Database not configured." });

  var siteUrl = config.siteUrl || "";
  var linkColor = config.colorSecondary || "#059669";
  var validPlanKeys = Object.keys(config.plans);

  /* ========== GET - fetch employer jobs ========== */
  if (req.method === "GET") {
    var email = req.query.email;
    var password = req.query.password;
    if (!email || !password) return res.status(400).json({ error: "Missing credentials" });
    try {
      var empRaw = await hget("employers", email);
      if (!empRaw) return res.status(401).json({ error: "Account not found" });
      var emp = typeof empRaw === "string" ? JSON.parse(empRaw) : empRaw;
      if (!verifyPassword(password, emp.password)) return res.status(401).json({ error: "Incorrect password" });

      /* Auto-upgrade plaintext password to hashed */
      if (!isHashed(emp.password)) { emp.password = hashPassword(password); await hset("employers", email, emp); }

      var raw = await hgetall("jobs");
      var jobs = Object.values(raw)
        .map(function(j) { return typeof j === "string" ? JSON.parse(j) : j; })
        .filter(function(j) { return j.email === email; })
        .sort(function(a, b) { return new Date(b.submitted) - new Date(a.submitted); });
      return res.status(200).json({
        success: true,
        employer: { name: emp.name, company: emp.company, email: emp.email, plan: emp.plan || "free" },
        jobs: jobs
      });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  /* ========== POST - actions ========== */
  if (req.method === "POST") {
    var action = req.body.action;
    var postEmail = req.body.email;
    var postPassword = req.body.password;
    var jobId = req.body.jobId;
    var updates = req.body.updates;
    if (!postEmail || !postPassword) return res.status(400).json({ error: "Missing credentials" });

    try {
      var empRaw2 = await hget("employers", postEmail);
      if (!empRaw2) return res.status(401).json({ error: "Account not found" });
      var emp2 = typeof empRaw2 === "string" ? JSON.parse(empRaw2) : empRaw2;
      if (!verifyPassword(postPassword, emp2.password)) return res.status(401).json({ error: "Incorrect password" });

      /* Auto-upgrade plaintext password to hashed */
      if (!isHashed(emp2.password)) { emp2.password = hashPassword(postPassword); await hset("employers", postEmail, emp2); }

      /* ---- List employer jobs (POST variant) ---- */
      if (action === "list") {
        var allRaw = await hgetall("jobs");
        var allJobs2 = Object.values(allRaw)
          .map(function(j) { return typeof j === "string" ? JSON.parse(j) : j; })
          .filter(function(j) { return j.email === postEmail; })
          .sort(function(a, b) { return new Date(b.submitted) - new Date(a.submitted); });
        return res.status(200).json({
          success: true,
          employer: { name: emp2.name, company: emp2.company, email: emp2.email, plan: emp2.plan || "free" },
          jobs: allJobs2
        });
      }

      /* ---- Upgrade plan ---- */
      if (action === "upgrade") {
        var newPlan = req.body.plan;
        if (!newPlan || validPlanKeys.indexOf(newPlan) === -1) return res.status(400).json({ error: "Invalid plan" });
        emp2.plan = newPlan;
        emp2.planChangedAt = new Date().toISOString();
        await hset("employers", postEmail, emp2);
        return res.status(200).json({ success: true, plan: newPlan });
      }

      /* ---- Submit new job listing ---- */
      if (action === "submit") {
        var planKey = emp2.plan || "free";
        var planConfig = config.plans[planKey] || config.plans.free;
        var sTitle = req.body.title;
        var sDesc = req.body.description;
        if (!sTitle || !sDesc) return res.status(400).json({ error: "Missing job title or description" });

        /* Check active listing limit */
        var limit = PLAN_LIMITS[planKey] || 1;
        if (limit < 999) {
          var allJobs = await hgetall("jobs");
          var active = Object.values(allJobs)
            .map(function(j) { return typeof j === "string" ? JSON.parse(j) : j; })
            .filter(function(j) { return j.email === postEmail && (j.status === "approved" || j.status === "pending"); });
          if (active.length >= limit) {
            return res.status(400).json({
              error: "Your " + (PLAN_NAMES[planKey] || planKey) + " plan allows " + limit + " active listing" + (limit > 1 ? "s" : "") + ". You have " + active.length + " active. Upgrade your plan to post more.",
              limitReached: true
            });
          }
        }

        /* Generate unique job ID and reference number */
        var jid = "job_" + Date.now() + "_" + Math.random().toString(36).substring(2, 8);
        var refNum = "JB-" + Date.now().toString(36).toUpperCase().slice(-4) + Math.random().toString(36).substring(2, 4).toUpperCase();

        /* Determine plan features */
        var features = planConfig.features || {};
        var durationDays = PLAN_DAYS[planKey] || 30;

        var newJob = {
          id: jid,
          ref: refNum,
          employerId: req.body.employerId || "",
          company: emp2.company || req.body.company,
          email: postEmail,
          title: sTitle,
          location: req.body.location || "",
          category: req.body.category || "Other",
          type: req.body.type || "Full-time",
          salary: req.body.salary || "Negotiable",
          description: sDesc,
          requirements: req.body.requirements || "",
          why: req.body.why || "",
          companyProfile: features.companyProfile ? (req.body.companyProfile || "") : "",
          website: req.body.website || "",
          logoUrl: features.logo ? (req.body.logoUrl || "") : "",
          plan: planKey,
          planDays: durationDays,
          autoFeature: !!features.featured,
          priority: !!features.priority,
          status: "pending",
          submitted: new Date().toISOString(),
          views: 0,
          applies: 0
        };

        await hset("jobs", jid, newJob);

        notifyAdmin(
          "New job submitted: " + sTitle + " - " + (emp2.company || ""),
          "A new job listing needs your review:<br><br>"
          + "<strong>" + (sTitle || "") + "</strong><br>"
          + "Company: " + (emp2.company || "") + "<br>"
          + "Location: " + (req.body.location || "") + "<br>"
          + "Category: " + (req.body.category || "Other") + "<br>"
          + "Type: " + (req.body.type || "Full-time") + "<br>"
          + "Plan: " + planKey + "<br><br>"
          + '<a href="' + siteUrl + '/admin.html" style="color:' + linkColor + ';font-weight:700">Review in admin panel</a>'
        );
        return res.status(200).json({ success: true, id: jid });
      }

      /* All remaining actions require a jobId */
      if (!jobId) return res.status(400).json({ error: "Missing job ID" });
      var jobRaw = await hget("jobs", jobId);
      if (!jobRaw) return res.status(404).json({ error: "Job not found" });
      var job = typeof jobRaw === "string" ? JSON.parse(jobRaw) : jobRaw;
      if (job.email !== postEmail) return res.status(403).json({ error: "Not your listing" });

      /* ---- Edit listing ---- */
      if (action === "edit") {
        if (!updates || typeof updates !== "object") return res.status(400).json({ error: "Missing or invalid updates" });
        var allowed = ["title", "location", "category", "type", "salary", "description", "requirements", "why", "companyProfile", "logoUrl"];
        var editPlan = emp2.plan || "free";
        var editFeatures = (config.plans[editPlan] && config.plans[editPlan].features) || {};

        allowed.forEach(function(k) { if (updates[k] !== undefined) job[k] = updates[k]; });

        /* Free plan cannot have logo or company profile */
        if (!editFeatures.logo) job.logoUrl = "";
        if (!editFeatures.companyProfile) job.companyProfile = "";

        job.editedAt = new Date().toISOString();
        if (job.status !== "approved") {
          job.status = "pending";
          job.editNote = "Resubmitted by employer after edit";
        }
        await hset("jobs", jobId, job);
        return res.status(200).json({ success: true });
      }

      /* ---- Relist ---- */
      if (action === "relist") {
        if (job.status !== "approved" && job.status !== "closed") {
          return res.status(400).json({ error: "Only expired or closed listings can be relisted" });
        }
        var currentPlan = emp2.plan || "free";
        var currentFeatures = (config.plans[currentPlan] && config.plans[currentPlan].features) || {};
        job.plan = currentPlan;
        job.planDays = PLAN_DAYS[currentPlan] || 30;
        job.approvedAt = new Date().toISOString();
        job.featured = !!currentFeatures.featured;
        job.priority = !!currentFeatures.priority;
        job.status = "pending";
        job.relistedAt = new Date().toISOString();
        await hset("jobs", jobId, job);
        return res.status(200).json({ success: true });
      }

      /* ---- Close listing ---- */
      if (action === "close") {
        job.status = "closed";
        job.closedAt = new Date().toISOString();
        await hset("jobs", jobId, job);
        return res.status(200).json({ success: true });
      }

      /* ---- Delete employer account ---- */
      if (action === "delete-account") {
        var hdel = _kv.hdel;
        /* Delete all their jobs */
        var allJobsDel = await hgetall("jobs");
        var empJobs = Object.entries(allJobsDel).filter(function(e) {
          var j = typeof e[1] === "string" ? JSON.parse(e[1]) : e[1];
          return j.email === postEmail;
        });
        for (var d = 0; d < empJobs.length; d++) { await hdel("jobs", empJobs[d][0]); }
        /* Delete employer record */
        await hdel("employers", postEmail);
        return res.status(200).json({ success: true });
      }

      return res.status(400).json({ error: "Unknown action" });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  return res.status(405).json({ error: "Method not allowed" });
};
