/**
 * Employer Registration & Login — /api/register
 *
 * POST { action: "register", name, company, email, password, plan }
 * POST { action: "login", email, password }
 */

var config = require("../config");
var _kv = require("./_kv");
var getKV = _kv.getKV;
var hget = _kv.hget;
var hset = _kv.hset;
var hashPassword = _kv.hashPassword;
var verifyPassword = _kv.verifyPassword;
var isHashed = _kv.isHashed;
var validatePassword = _kv.validatePassword;

var rateMap = {};

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  if (!getKV()) return res.status(500).json({ error: "Database not configured." });

  var action = req.body.action;

  // Rate limiting
  var ip = (req.headers["x-forwarded-for"] || "unknown").split(",")[0].trim();
  var now = Date.now();
  if (!rateMap[ip] || now - rateMap[ip].start > 60000) rateMap[ip] = { start: now, count: 0 };
  rateMap[ip].count++;
  if (rateMap[ip].count > config.rateLimits.auth) {
    return res.status(429).json({ error: "Too many attempts. Try again in a minute." });
  }

  if (action === "register") {
    var name = (req.body.name || "").trim();
    var company = (req.body.company || "").trim();
    var email = (req.body.email || "").trim().toLowerCase();
    var password = req.body.password || "";
    var plan = req.body.plan || "free";

    if (!name || !company || !email || !password) {
      return res.status(400).json({ error: "All fields are required." });
    }

    var pwErr = validatePassword(password);
    if (pwErr) return res.status(400).json({ error: pwErr });

    var existing = await hget("employers", email);
    if (existing) return res.status(400).json({ error: "An account with this email already exists." });

    var emp = {
      id: "emp_" + Date.now(),
      name: name,
      company: company,
      email: email,
      password: hashPassword(password),
      plan: plan,
      phone: (req.body.phone || "").trim(),
      website: (req.body.website || "").trim(),
      registered: new Date().toISOString(),
      status: "active"
    };

    await hset("employers", email, emp);

    // Send admin notification if email is configured
    await notifyAdmin("New employer registered: " + company + " (" + email + ") — Plan: " + plan);

    return res.status(200).json({
      success: true,
      id: emp.id,
      name: emp.name,
      company: emp.company,
      email: emp.email,
      plan: emp.plan
    });
  }

  if (action === "login") {
    var loginEmail = (req.body.email || "").trim().toLowerCase();
    var loginPass = req.body.password || "";

    if (!loginEmail || !loginPass) return res.status(400).json({ error: "Email and password required." });

    var emp2 = await hget("employers", loginEmail);
    if (!emp2) return res.status(401).json({ error: "Invalid email or password." });
    if (typeof emp2 === "string") emp2 = JSON.parse(emp2);

    if (!verifyPassword(loginPass, emp2.password)) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    // Auto-upgrade plaintext passwords to hashed
    if (!isHashed(emp2.password)) {
      emp2.password = hashPassword(loginPass);
      await hset("employers", loginEmail, emp2);
    }

    return res.status(200).json({
      success: true,
      id: emp2.id,
      name: emp2.name,
      company: emp2.company,
      email: emp2.email,
      plan: emp2.plan
    });
  }

  return res.status(400).json({ error: "Invalid action." });
};


async function notifyAdmin(message) {
  var resendKey = process.env.RESEND_API_KEY;
  var adminEmail = process.env.ADMIN_EMAIL;
  if (!resendKey || !adminEmail) return;

  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + resendKey },
      body: JSON.stringify({
        from: config.emailFromName + " <noreply@" + config.emailFromDomain + ">",
        to: adminEmail,
        subject: "[" + config.siteName + "] " + message.substring(0, 80),
        text: message
      })
    });
  } catch (e) { /* email is optional */ }
}
