/**
 * Job Search API — /api/jobs
 *
 * Searches for jobs using the configured aggregator API.
 * Supports: Adzuna, JSearch, Jooble, Reed, Careerjet, or none.
 *
 * POST { query: string, country?: string, limit?: number }
 * Returns { jobs: [{ title, company, location, salary, description, url }] }
 */

var config = require("../config");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  var query = (req.body.query || "").trim();
  var country = (req.body.country || config.defaultCountry).toLowerCase();
  var limit = Math.min(parseInt(req.body.limit) || 10, 30);

  if (!query) return res.status(400).json({ error: "Query required", jobs: [] });

  var aggregator = config.jobAggregator;

  try {
    var jobs = [];

    if (aggregator === "adzuna") {
      jobs = await searchAdzuna(query, country, limit);
    } else if (aggregator === "jsearch") {
      jobs = await searchJSearch(query, country, limit);
    } else if (aggregator === "jooble") {
      jobs = await searchJooble(query, country, limit);
    } else if (aggregator === "reed") {
      jobs = await searchReed(query, limit);
    } else if (aggregator === "careerjet") {
      jobs = await searchCareerjet(query, country, limit);
    } else {
      // aggregator = "none" — return empty, only employer-posted jobs shown
      return res.status(200).json({ jobs: [] });
    }

    // Filter spam
    jobs = filterSpam(jobs);

    return res.status(200).json({ jobs: jobs.slice(0, limit) });
  } catch (err) {
    console.error("Job search error:", err.message);
    return res.status(200).json({ jobs: [] });
  }
};


// ============================================
// ADZUNA — developer.adzuna.com
// ============================================

async function searchAdzuna(query, country, limit) {
  var appId = process.env.ADZUNA_APP_ID;
  var appKey = process.env.ADZUNA_APP_KEY;
  if (!appId || !appKey) return [];

  var url = "https://api.adzuna.com/v1/api/jobs/" + country + "/search/1"
    + "?app_id=" + appId + "&app_key=" + appKey
    + "&results_per_page=" + Math.min(limit * 2, 30)
    + "&what=" + encodeURIComponent(query)
    + "&content-type=application/json";

  var r = await fetch(url, { headers: { "Accept": "application/json" } });
  if (!r.ok) return [];
  var data = await r.json();
  if (!data.results) return [];

  return data.results.map(function(j) {
    return {
      title: j.title || "",
      company: (j.company && j.company.display_name) || "Company",
      location: (j.location && j.location.display_name) || "",
      salary: formatSalary(j.salary_min, j.salary_max),
      description: (j.description || "").substring(0, 300),
      url: j.redirect_url || ""
    };
  });
}


// ============================================
// JSEARCH — rapidapi.com (global)
// ============================================

async function searchJSearch(query, country, limit) {
  var apiKey = process.env.JSEARCH_API_KEY;
  if (!apiKey) return [];

  // Map country codes to JSearch country filter
  var countryMap = { us: "US", gb: "GB", ca: "CA", au: "AU", nz: "NZ", de: "DE", fr: "FR", in: "IN", sg: "SG" };
  var countryFilter = countryMap[country] || "";

  var searchQuery = query + (countryFilter ? " in " + countryFilter : "");

  var r = await fetch("https://jsearch.p.rapidapi.com/search?query=" + encodeURIComponent(searchQuery) + "&num_pages=1", {
    headers: {
      "X-RapidAPI-Key": apiKey,
      "X-RapidAPI-Host": "jsearch.p.rapidapi.com"
    }
  });
  if (!r.ok) return [];
  var data = await r.json();
  if (!data.data) return [];

  return data.data.map(function(j) {
    return {
      title: j.job_title || "",
      company: j.employer_name || "Company",
      location: j.job_city ? (j.job_city + ", " + (j.job_state || "")) : (j.job_country || ""),
      salary: j.job_min_salary && j.job_max_salary ? ("$" + Math.round(j.job_min_salary) + " - $" + Math.round(j.job_max_salary)) : "",
      description: (j.job_description || "").substring(0, 300),
      url: j.job_apply_link || j.job_google_link || ""
    };
  });
}


// ============================================
// JOOBLE — jooble.org/api/about
// ============================================

async function searchJooble(query, country, limit) {
  var apiKey = process.env.JOOBLE_API_KEY;
  if (!apiKey) return [];

  // Jooble uses country-specific subdomains
  var countryMap = { us: "us", gb: "uk", au: "au", nz: "nz", ca: "ca", de: "de", fr: "fr", in: "in", sg: "sg", za: "za" };
  var countryCode = countryMap[country] || "us";

  var r = await fetch("https://jooble.org/api/" + apiKey, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ keywords: query, location: "", page: 1 })
  });
  if (!r.ok) return [];
  var data = await r.json();
  if (!data.jobs) return [];

  return data.jobs.slice(0, limit).map(function(j) {
    return {
      title: j.title || "",
      company: j.company || "Company",
      location: j.location || "",
      salary: j.salary || "",
      description: (j.snippet || "").substring(0, 300),
      url: j.link || ""
    };
  });
}


// ============================================
// REED — reed.co.uk/developers (UK only)
// ============================================

async function searchReed(query, limit) {
  var apiKey = process.env.REED_API_KEY;
  if (!apiKey) return [];

  var r = await fetch("https://www.reed.co.uk/api/1.0/search?keywords=" + encodeURIComponent(query) + "&resultsToTake=" + limit, {
    headers: { "Authorization": "Basic " + Buffer.from(apiKey + ":").toString("base64") }
  });
  if (!r.ok) return [];
  var data = await r.json();
  if (!data.results) return [];

  return data.results.map(function(j) {
    return {
      title: j.jobTitle || "",
      company: j.employerName || "Company",
      location: j.locationName || "",
      salary: j.minimumSalary && j.maximumSalary ? ("\u00a3" + j.minimumSalary.toLocaleString() + " - \u00a3" + j.maximumSalary.toLocaleString()) : "",
      description: (j.jobDescription || "").substring(0, 300),
      url: j.jobUrl || ""
    };
  });
}


// ============================================
// CAREERJET — careerjet.com/partners
// ============================================

async function searchCareerjet(query, country, limit) {
  var affId = process.env.CAREERJET_AFFID;
  if (!affId) return [];

  var localeMap = { us: "en_US", gb: "en_GB", au: "en_AU", nz: "en_NZ", ca: "en_CA", de: "de_DE", fr: "fr_FR", in: "en_IN", sg: "en_SG", za: "en_ZA" };
  var locale = localeMap[country] || "en_US";

  var r = await fetch("http://public.api.careerjet.net/search?keywords=" + encodeURIComponent(query) + "&locale_code=" + locale + "&affid=" + affId + "&pagesize=" + limit);
  if (!r.ok) return [];
  var data = await r.json();
  if (!data.jobs) return [];

  return data.jobs.map(function(j) {
    return {
      title: j.title || "",
      company: j.company || "Company",
      location: j.locations || "",
      salary: j.salary || "",
      description: (j.description || "").substring(0, 300),
      url: j.url || ""
    };
  });
}


// ============================================
// HELPERS
// ============================================

function formatSalary(min, max) {
  if (!min && !max) return "";
  if (min && max) return "$" + Math.round(min).toLocaleString() + " - $" + Math.round(max).toLocaleString();
  if (min) return "From $" + Math.round(min).toLocaleString();
  return "Up to $" + Math.round(max).toLocaleString();
}

function filterSpam(jobs) {
  var badTitles = config.spamTitleWords.map(function(w) { return w.toLowerCase(); });
  var badDomains = config.spamDomains.map(function(d) { return d.toLowerCase(); });

  return jobs.filter(function(j) {
    var title = (j.title || "").toLowerCase();
    var url = (j.url || "").toLowerCase();
    for (var i = 0; i < badTitles.length; i++) {
      if (title.indexOf(badTitles[i]) !== -1) return false;
    }
    for (var d = 0; d < badDomains.length; d++) {
      if (url.indexOf(badDomains[d]) !== -1) return false;
    }
    return true;
  });
}
