/**
 * AI Chat API — /api/chat
 *
 * Proxies requests to the Anthropic Claude API.
 * Used for CV-to-job matching, blog generation, and social media content.
 *
 * POST { messages: Array, system?: string }
 * Returns: Anthropic API response
 */

var config = require("../config");

var rateMap = {};

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  var apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "AI not configured. Set ANTHROPIC_API_KEY." });

  // Rate limiting
  var ip = (req.headers["x-forwarded-for"] || "unknown").split(",")[0].trim();
  var now = Date.now();
  if (!rateMap[ip] || now - rateMap[ip].start > 60000) {
    rateMap[ip] = { start: now, count: 0 };
  }
  rateMap[ip].count++;
  if (rateMap[ip].count > config.aiRateLimit) {
    return res.status(429).json({ error: "Too many requests. Try again in a minute." });
  }

  var messages = req.body.messages;
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Messages required." });
  }
  if (messages.length > config.aiMaxMessages) {
    return res.status(400).json({ error: "Too many messages." });
  }

  try {
    var body = {
      model: config.aiModel,
      max_tokens: 4096,
      messages: messages
    };
    if (req.body.system) body.system = req.body.system;

    var r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify(body)
    });

    var data = await r.json();
    return res.status(200).json(data);
  } catch (err) {
    console.error("Chat API error:", err.message);
    return res.status(500).json({ error: "AI request failed." });
  }
};
