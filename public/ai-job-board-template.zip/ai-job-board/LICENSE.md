# License

This item is sold under the Envato Regular License or Extended License.

See https://codecanyon.net/licenses/standard for license terms.

You may NOT redistribute, resell, or share this code without a valid license.
