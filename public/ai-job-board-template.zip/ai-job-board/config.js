/**
 * AI Job Board — Configuration
 *
 * Edit this file to customise your job board.
 * All settings are in one place for easy setup.
 */

module.exports = {

  // ============================================
  // SITE IDENTITY
  // ============================================

  siteName: "AI Job Board",           // Your site name
  siteTagline: "AI-Powered Job Matching",
  siteUrl: "https://www.example.com", // Your domain (no trailing slash)
  siteDescription: "Upload your CV and let AI match you to the best jobs. Free for job seekers.",
  siteCopyright: "2026",

  // Brand colours (CSS values)
  colorPrimary: "#10b981",     // Main accent (buttons, links)
  colorSecondary: "#059669",   // Hover states
  colorPurple: "#8b5cf6",      // Category accent
  colorGold: "#f59e0b",        // Category accent
  colorPink: "#ec4899",        // Category accent

  // ============================================
  // COUNTRY & REGION
  // ============================================

  defaultCountry: "nz",        // Default country code
  defaultCountryName: "New Zealand",
  defaultCurrency: "$",

  // Supported countries for job search
  // Users can pick from these in the country selector
  countries: [
    { code: "nz", name: "New Zealand", flag: "\ud83c\uddf3\ud83c\uddff", currency: "$" },
    { code: "au", name: "Australia", flag: "\ud83c\udde6\ud83c\uddfa", currency: "A$" },
    { code: "gb", name: "United Kingdom", flag: "\ud83c\uddec\ud83c\udde7", currency: "\u00a3" },
    { code: "us", name: "United States", flag: "\ud83c\uddfa\ud83c\uddf8", currency: "$" },
    { code: "ca", name: "Canada", flag: "\ud83c\udde8\ud83c\udde6", currency: "C$" },
    { code: "de", name: "Germany", flag: "\ud83c\udde9\ud83c\uddea", currency: "\u20ac" },
    { code: "fr", name: "France", flag: "\ud83c\uddeb\ud83c\uddf7", currency: "\u20ac" },
    { code: "in", name: "India", flag: "\ud83c\uddee\ud83c\uddf3", currency: "\u20b9" },
    { code: "sg", name: "Singapore", flag: "\ud83c\uddf8\ud83c\uddec", currency: "S$" },
    { code: "za", name: "South Africa", flag: "\ud83c\uddff\ud83c\udde6", currency: "R" }
  ],

  // ============================================
  // JOB AGGREGATOR API
  // ============================================
  //
  // Choose which job API to use for fetching live job listings.
  // Set to "none" to only show employer-posted jobs.
  //
  // Options:
  //   "adzuna"    — Free. 15+ countries. developer.adzuna.com
  //   "jsearch"   — Via RapidAPI. Global. rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
  //   "jooble"    — Free. 60+ countries. jooble.org/api/about
  //   "careerjet" — Multi-country. careerjet.com/partners
  //   "reed"      — UK only. reed.co.uk/developers
  //   "none"      — No aggregator. Only show jobs posted by employers.
  //
  jobAggregator: "adzuna",

  // Adzuna credentials (if jobAggregator = "adzuna")
  // Sign up free at developer.adzuna.com
  // Set via environment variables ADZUNA_APP_ID and ADZUNA_APP_KEY

  // JSearch credentials (if jobAggregator = "jsearch")
  // Sign up at rapidapi.com — set JSEARCH_API_KEY env var

  // Jooble credentials (if jobAggregator = "jooble")
  // Sign up at jooble.org/api/about — set JOOBLE_API_KEY env var

  // Reed credentials (if jobAggregator = "reed")
  // Sign up at reed.co.uk/developers — set REED_API_KEY env var

  // Careerjet credentials (if jobAggregator = "careerjet")
  // Set CAREERJET_AFFID env var

  // Spam filter — job titles containing these words are hidden
  spamTitleWords: [
    "no experience", "remote usa", "work from home worldwide",
    "entry level remote", "hiring immediately"
  ],

  // Spam filter — jobs from these domains are hidden
  spamDomains: [
    "flexjobs.com", "remoteco.com", "remote.co"
  ],

  // ============================================
  // AI PROVIDER
  // ============================================
  //
  // The AI model used for job matching and content generation.
  // Set ANTHROPIC_API_KEY environment variable.
  //
  aiModel: "claude-sonnet-4-20250514",
  aiMaxMessages: 10,
  aiRateLimit: 30,  // requests per minute per IP

  // ============================================
  // EMPLOYER PLANS
  // ============================================

  plans: {
    free: {
      name: "Free",
      price: 0,
      maxListings: 1,
      durationDays: 30,
      features: {
        logo: false,
        companyProfile: false,
        priority: false,
        featured: false,
        aiMatching: false
      }
    },
    basic: {
      name: "Basic",
      price: 29,
      maxListings: 5,
      durationDays: 60,
      features: {
        logo: true,
        companyProfile: true,
        priority: true,
        featured: false,
        aiMatching: false
      }
    },
    pro: {
      name: "Pro",
      price: 79,
      maxListings: -1,  // unlimited
      durationDays: 90,
      features: {
        logo: true,
        companyProfile: true,
        priority: true,
        featured: true,
        aiMatching: true
      }
    }
  },

  // Launch promotion — all plans get extended duration until this date
  // Set to null to disable
  launchPromoEnd: null,  // e.g. "2026-10-01"
  launchPromoDays: 90,

  // ============================================
  // EMAIL (OPTIONAL)
  // ============================================
  //
  // Uses Resend for transactional emails.
  // Set RESEND_API_KEY and ADMIN_EMAIL environment variables.
  // If not set, the site works fine — just no email notifications.
  //
  emailFromName: "AI Job Board",
  emailFromDomain: "example.com",  // Must match your Resend verified domain

  // ============================================
  // BLOG
  // ============================================

  blogEnabled: true,
  blogTitle: "Job Market Insights",
  blogDescription: "Tips for job seekers and employers",
  blogMaxPosts: 50,   // Maximum stored posts

  // ============================================
  // CRON / AUTOMATED ALERTS
  // ============================================

  // Weekly job alert emails to seekers
  // Runs via Vercel cron (see vercel.json)
  alertsEnabled: true,
  alertDay: 1,  // 0=Sunday, 1=Monday, ..., 6=Saturday
  alertMaxJobs: 5,  // Max jobs per alert email

  // ============================================
  // RATE LIMITING
  // ============================================

  rateLimits: {
    chat: 30,       // AI requests per minute per IP
    auth: 10,       // Login attempts per minute per IP
    admin: 5        // Admin requests per minute per IP
  },

  // ============================================
  // PASSWORD REQUIREMENTS
  // ============================================

  passwordMinLength: 8,
  passwordRequireUppercase: true,
  passwordRequireLowercase: true,
  passwordRequireDigit: true,
  passwordRequireSpecial: true
};
